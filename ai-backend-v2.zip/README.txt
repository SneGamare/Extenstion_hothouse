# Smart Autofill AI Backend v2 (OpenAI-enabled)
Adds OpenAI function-calling extraction.

## Setup
1) Node 18+
2) Copy .env.sample to .env and set:
   OPENAI_API_KEY=sk-...your_key...
   PORT=8787
   MODEL=gpt-4o-mini
3) npm install
4) npm start

Endpoint: POST /parse-and-score
Body: { url, snippet, profile }
Returns: { context, extracted, recommendation, model }

Falls back to regex extractors if the LLM returns nothing.
Deterministic scoring remains in code.
