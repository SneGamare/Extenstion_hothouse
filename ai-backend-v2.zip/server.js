import express from "express";
import cors from "cors";
import OpenAI from "openai";

const PORT = process.env.PORT || 8787;
const MODEL = process.env.MODEL || "gpt-4o-mini";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

function extractFd(text) {
  const pctRe = /(\d{1,2}(?:\.\d{1,2})?)\s*%/g;
  const tenRe = /(\d{1,2})\s*(months|month|mo|year|years|yr|yrs)/i;
  let m, rates = [];
  while ((m = pctRe.exec(text)) !== null) {
    const val = parseFloat(m[1]);
    if (!isNaN(val) && val > 0 && val < 25) rates.push(val);
    if (rates.length > 10) break;
  }
  const tenureMatch = text.match(tenRe);
  const tenureMonths = tenureMatch
    ? /year/i.test(tenureMatch[2]) ? parseInt(tenureMatch[1]) * 12 : parseInt(tenureMatch[1])
    : null;
  const interest_rate_pct = rates.length ? Math.max(...rates) : null;
  return {
    product_type: "fixed_deposit",
    bank: null,
    tenure_months: tenureMonths,
    interest_rate_pct,
    min_deposit: null,
    lock_in_days: null,
    annual_fee: null,
    reward_rate: null,
    notes: []
  };
}

function extractCard(text) {
  const feeRe = /annual fee[^\d]*(\d{1,3}(?:[,\d]{0,6})?)/i;
  const feeM = text.match(feeRe);
  const annual_fee = feeM ? Number(String(feeM[1]).replace(/,/g, "")) : null;
  const pctRe = /(\d{1,2}(?:\.\d{1,2})?)\s*%/g;
  let bestPct = null, m;
  while ((m = pctRe.exec(text)) !== null) {
    const val = parseFloat(m[1]); if (val>0 && val<50) bestPct = Math.max(bestPct??0, val);
  }
  return {
    product_type: "credit_card",
    bank: null,
    annual_fee,
    reward_rate: bestPct,
    notes: []
  };
}

function scoreFd(fd, profile) {
  const existing = profile?.fd_rate_pct ?? 7.2;
  const res = { tag: "info", msg: "FD detected. Not enough data." };
  if (fd.interest_rate_pct == null) {
    res.tag = "info";
    res.msg = "FD page detected, but couldn't find a clear interest rate.";
    return res;
  }
  const delta = fd.interest_rate_pct - existing;
  if (delta >= 0.25) {
    res.tag = "good";
    res.msg = `Better FD rate detected: ${fd.interest_rate_pct}% vs your ${existing}% → Consider switching.`;
  } else if (delta <= -0.25) {
    res.tag = "warn";
    res.msg = `Worse FD rate: ${fd.interest_rate_pct}% vs your ${existing}% → Likely skip.`;
  } else {
    res.tag = "info";
    res.msg = `Similar FD rate: ${fd.interest_rate_pct}% vs your ${existing}% → Neutral.`;
  }
  return res;
}

function scoreCard(card, profile) {
  const spend = profile?.spend_profile || { online:0.4, travel:0.3, dining:0.3, monthly_spend_inr:60000 };
  const annual_fee = card.annual_fee ?? 0;
  const reward_hint = card.reward_rate ?? null;
  if (reward_hint && reward_hint >= 1.5 && annual_fee <= 1500) {
    return { tag:"good", msg:`Looks promising: reward ~${reward_hint}% and fee ₹${annual_fee||0}. Compare to your current cards.` };
  }
  if (annual_fee && annual_fee > 3500) {
    return { tag:"warn", msg:`High annual fee (₹${annual_fee}). Ensure benefits exceed fee for your ₹${spend.monthly_spend_inr}/mo spend.` };
  }
  return { tag:"info", msg:"Credit card detected. Evaluate rewards vs your spend mix and fees." };
}

async function llmExtract(snippet, hint) {
  const tool = {
    type: "function",
    function: {
      name: "extract_product",
      description: "Extract structured data for a financial product page.",
      parameters: {
        type: "object",
        properties: {
          product_type: { type: "string", enum: ["fixed_deposit","credit_card"] },
          bank: { type: "string", nullable: true },
          interest_rate_pct: { type: "number", nullable: true },
          tenure_months: { type: "number", nullable: true },
          min_deposit: { type: "number", nullable: true },
          lock_in_days: { type: "number", nullable: true },
          annual_fee: { type: "number", nullable: true },
          reward_rate: { type: "number", nullable: true },
          notes: { type: "array", items: { type:"string" }, nullable: true }
        },
        required: ["product_type"]
      }
    }
  };

  const messages = [
    { role: "system", content: "You extract structured product details from noisy website text. Respond only via the provided function." },
    { role: "user", content: `Text from page (lowercased):\n${snippet}\nHint: ${hint||"unknown"}` }
  ];

  const completion = await client.chat.completions.create({
    model: MODEL,
    messages,
    tools: [tool],
    tool_choice: "auto",
    temperature: 0.1
  });

  const call = completion.choices?.[0]?.message?.tool_calls?.[0];
  if (call?.function?.arguments) {
    try {
      return JSON.parse(call.function.arguments);
    } catch (e) {
      console.warn("Failed to parse function args:", e);
    }
  }
  return null;
}

import dotenv from "dotenv";
dotenv.config();

import http from "http";

import { fileURLToPath } from "url";
import { dirname } from "path";
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

app.post("/parse-and-score", async (req, res) => {
  try {
    const { url, snippet, profile } = req.body || {};
    const text = (snippet || "").toLowerCase();
    const isFD = /fixed deposit|fd rate|interest rate|time deposit/.test(text);
    const isCC = /credit card|annual fee|reward points|lounge access|cashback/.test(text);

    let context = "general";
    if (isFD && !isCC) context = "fd";
    if (isCC && !isFD) context = "credit_card";

    let extracted = null;

    if (context === "fd") {
      extracted = await llmExtract(text, "fixed_deposit");
      if (!extracted || extracted.product_type !== "fixed_deposit") {
        extracted = extractFd(text);
      }
    } else if (context === "credit_card") {
      extracted = await llmExtract(text, "credit_card");
      if (!extracted || extracted.product_type !== "credit_card") {
        extracted = extractCard(text);
      }
    }

    let recommendation = { tag: "info", msg: "Browsing… No specific finance context detected yet." };
    if (context === "fd" && extracted) recommendation = scoreFd(extracted, profile);
    if (context === "credit_card" && extracted) recommendation = scoreCard(extracted, profile);

    res.json({ context, extracted, recommendation, model: MODEL });
  } catch (e) {
    console.error("parse-and-score error:", e);
    res.status(500).json({ error: "internal_error", message: e?.message || "Unknown error" });
  }
});

app.listen(PORT, () => console.log(`AI backend v2 running on http://localhost:${PORT}`));
