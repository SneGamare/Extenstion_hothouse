# Smart Autofill AI Backend v3 (OpenAI-enabled)
Adds OpenAI function-calling extraction and financial advice.

## Setup
1) Node 18+
2) Copy .env.sample to .env and set:
   OPENAI_API_KEY=sk-...your_key...
   PORT=3000
   MODEL=gpt-4o-mini
3) npm install
4) npm start

Endpoint: POST /advice
Body: { url, question, snippet, profile, context }
Returns: { answer, decision, extracted }

Uses OpenAI function-calling to extract structured product data and provides personalized financial advice based on user profile.

## Backend API (local development)
POST http://localhost:3000/advice
Request JSON body: { url, snippet, profile, question, context }
Response JSON: { answer, decision, extracted }

Note: The extension content script calls /advice on localhost:3000.
