import express from "express";
import cors from "cors";
import OpenAI from "openai";
import dotenv from "dotenv";
dotenv.config();

const PORT = process.env.PORT || 8787;
const MODEL = process.env.MODEL || "gpt-4o-mini";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

// Health check
app.get("/healthz", (req, res) => {
  res.json({ status: "ok", model: MODEL });
});

// ---- function-calling tool for structured extraction
const extractTool = {
  type: "function",
  function: {
    name: "extract_product",
    description: "Extract structured data from a financial product page.",
    parameters: {
      type: "object",
      properties: {
        product_type: { type: "string", enum: ["fixed_deposit","credit_card","general"] },
        bank: { type: "string", nullable: true },
        // FD-ish
        interest_rate_pct: { type: "number", nullable: true },
        tenure_months: { type: "number", nullable: true },
        min_deposit: { type: "number", nullable: true },
        lock_in_days: { type: "number", nullable: true },
        // Card-ish
        annual_fee: { type: "number", nullable: true },
        reward_rate_base_pct: { type: "number", nullable: true },
        reward_rate_travel_pct: { type: "number", nullable: true },
        reward_rate_online_pct: { type: "number", nullable: true },
        reward_rate_dining_pct: { type: "number", nullable: true },
        fx_markup_pct: { type: "number", nullable: true },
        // Misc
        notes: { type: "array", items: { type:"string" }, nullable: true }
      },
      required: ["product_type"]
    }
  }
};

function summarizeProfile(profile){
  const totalSavings = (profile?.cash?.savings_accounts||[]).reduce((s,a)=>s+(a.balance_inr||0),0);
  const totalFD = (profile?.deposits?.fds||[]).reduce((s,a)=>s+(a.amount_inr||0),0);
  const totalMF = (profile?.investments?.mutual_funds||[]).reduce((s,a)=>s+(a.value_inr||0),0);
  const spend = profile?.spend_profile || {};
  return { totalSavings, totalFD, totalMF, spend };
}

// ---- Advice endpoint
app.post("/advice", async (req, res) => {
  try{
      const { url, question, snippet, profile, context } = req.body || {};

  // basic validation
  if (!snippet || !profile) {
    return res.status(400).json({ error: "invalid_request", message: "snippet and profile are required in request body" });
  }

  const profSummary = summarizeProfile(profile);

    // 1) Extract product facts from page text
    const extract = await client.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: "You are a precise extractor of financial product details. Respond using the provided function only." },
        { role: "user", content: `URL: ${url}\nContext hint: ${context}\nPage text (lowercased):\n${(snippet||"").toLowerCase().slice(0,12000)}` }
      ],
      tools: [extractTool],
      tool_choice: "auto",
      temperature: 0.1
    });

    let extracted = null;

    // Simple deterministic fallback extractor (runs if the model tool returns nothing)
    function simpleFallbackExtractor(text){
      if(!text) return null;
      const out = {};
      // attempt to find an interest rate like 7.2% or 7.2 % or 7.2 percent
      const rateMatch = text.match(/(\d{1,2}(?:\.\d{1,2})?)\s*(?:%|percent|pct)\b/);
      if(rateMatch) out.interest_rate_pct = parseFloat(rateMatch[1]);
      // annual fee
      const feeMatch = text.match(/annual\s+fee[:\s]*₹?\s*([\d,]+)/i);
      if(feeMatch) {
        out.annual_fee_inr = parseInt(feeMatch[1].replace(/,/g,''),10);
      }
      // fx markup
      const fxMatch = text.match(/fx\s*(?:markup)?[:\s]*([\d\.]+)\s*(?:%|pct)/i);
      if(fxMatch) out.fx_markup_pct = parseFloat(fxMatch[1]);
      return Object.keys(out).length ? out : null;
    }

    const call = extract.choices?.[0]?.message?.tool_calls?.[0];
    if (call?.function?.arguments) {
      try { 
        extracted = JSON.parse(call.function.arguments);
        console.log("LLM extraction result:", extracted);
      } catch(e){
        console.warn("Failed to parse LLM extraction:", e);
      }
    } else {
      console.log("No tool call found in LLM response");
    }

    // 2) Ask the model for grounded advice using profile + extracted JSON
    const sys = `You are a fiduciary-style financial copilot for Indian retail users.
- Use ONLY the supplied profile JSON and extracted product JSON.
- Be concise, numeric, and practical (<=120 words).
- Surface fees, penalties, lock-ins, caps. Avoid hype.
- If uncertain, say what's missing and ask for exactly one detail.`;

    const user = `Question: ${question || "What should I do?"}
PROFILE(JSON):
${JSON.stringify(profile, null, 2)}
PROFILE_SUMMARY(JSON):
${JSON.stringify(profSummary, null, 2)}
EXTRACTED_PRODUCT(JSON):
${JSON.stringify(extracted||{product_type:context||"general"}, null, 2)}`;

    const advice = await client.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: sys },
        { role: "user", content: user }
      ],
      temperature: 0.2
    });

    const answer = advice.choices?.[0]?.message?.content?.trim();

    // If extraction was empty, try deterministic fallback on the snippet
    if (!extracted) {
      try {
        const fb = simpleFallbackExtractor(snippet);
        if (fb) {
          console.log('Using fallback extractor:', fb);
          extracted = fb;
        }
      } catch(e){ console.warn('fallback extractor failed', e); }
    }

    // Lightweight decision tag from wording (you can replace with numeric rules later)
    let decision = "consider";
    const lower = (answer||"").toLowerCase();
    if (/(skip|avoid|worse|not (recommended|worth)|hold off)/.test(lower)) decision = "skip";
    if (/(go ahead|apply|switch|good fit|better|worth it)/.test(lower)) decision = "go";

    console.log("Final response:", { answer: answer?.substring(0, 100) + "...", decision, extracted });
    const summary = (answer||'').split(/(?<=[\.\!\?])\s+/)[0] || (answer||'').slice(0,150);
    res.json({ answer, summary, decision, extracted });
  } catch(e){
    console.error("advice error:", e);
    res.status(500).json({ error: "internal_error", message: e?.message || "Unknown error" });
  }
});

app.listen(PORT, ()=> console.log("AI backend v3 running on http://localhost:"+PORT));
